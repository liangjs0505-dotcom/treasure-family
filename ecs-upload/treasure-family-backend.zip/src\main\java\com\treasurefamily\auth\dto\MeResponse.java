package com.treasurefamily.auth.dto;

public record MeResponse(String username) {
}
