package com.treasurefamily;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TreasureFamilyApplication {

    public static void main(String[] args) {
        SpringApplication.run(TreasureFamilyApplication.class, args);
    }
}
