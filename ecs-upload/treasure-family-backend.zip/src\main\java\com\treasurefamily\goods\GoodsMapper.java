package com.treasurefamily.goods;

import com.treasurefamily.goods.dto.GoodsRequest;
import com.treasurefamily.goods.dto.GoodsResponse;
import java.math.BigDecimal;

public final class GoodsMapper {

    private GoodsMapper() {
    }

    public static void apply(Goods goods, GoodsRequest request) {
        goods.setName(request.name().trim());
        goods.setCategory(request.category());
        goods.setPrice(request.price());
        goods.setStock(request.stock());
        goods.setUnit(request.unit().trim());
        goods.setSupplier(request.supplier() == null ? "" : request.supplier().trim());
        goods.setThreshold(request.threshold());
    }

    public static GoodsResponse toResponse(Goods goods) {
        BigDecimal price = goods.getPrice() == null ? BigDecimal.ZERO : goods.getPrice();
        return new GoodsResponse(
                goods.getId(),
                goods.getName(),
                goods.getCategory(),
                price,
                goods.getStock(),
                goods.getUnit(),
                goods.getSupplier() == null ? "" : goods.getSupplier(),
                goods.getThreshold(),
                goods.getCreatedAt(),
                goods.isLowStock(),
                goods.isOutOfStock());
    }
}
